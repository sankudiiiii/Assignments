package occurrences;
public class Count {
	public static final String[] occPrint = {"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
	public int[] occ = new int[10];
	public Count() {
		for (int i = 0; i < occ.length; i++) {
			occ[i]=0;
		}
	}
	public static void main(String[] args) {
		Count c = new Count();
		c.count("002021000");
		c.printOcc();
	}
	public void count(String num){
		int number = Integer.parseInt(num);
		if(number<0)
			number *= -1;
		do{
			int r = number % 10;
		this.occ[r]++;
		number/=10;
		}while(number>0);
	}
	public void printOcc(){
		for (int i = 0; i < this.occ.length; i++) {
			if(this.occ[i]!=0){
				System.out.println(i+" occurred "+occPrint[this.occ[i]]+" times.");
			}
		}
	}
}