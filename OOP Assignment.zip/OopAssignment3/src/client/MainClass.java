package client;
import geometry.Rectangle;
import geometry.Triangle;
public class MainClass {
	public static void main(String[] args) {
		Rectangle r = new Rectangle(10, 20);
		double rArea = r.calculateArea();
		System.out.println("Area of Rectangle : "+rArea);
		
		Triangle t = new Triangle(30, 40);
		double tArea = t.calculateArea();
		System.out.println("Area of Triangle : "+tArea);
	}
}