package geometry;
public class Triangle extends Shape {
	public Triangle() {
		super();
	}
	public Triangle(int width, int height) {
		super(width, height);
	}
	public double calculateArea() {
		return 0.5*this.getHeight()*this.getWidth();
	}	
}