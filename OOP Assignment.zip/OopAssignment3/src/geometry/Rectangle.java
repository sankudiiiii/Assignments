package geometry;
public class Rectangle extends Shape {
	public Rectangle() {
		super();
	}
	public Rectangle(int width, int height) {
		super(width, height);
	}
	public double calculateArea() {
		return this.getHeight()*this.getWidth();
	}
}