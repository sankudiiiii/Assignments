package person;
import bank.Account;
public class Employee extends Person {
	private int employeeId;
	public Employee() {
		super();
	}
	public Employee(String name, Account account) {
		super(name, account);
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String toString() {
		return super.toString()+" Employee [employeeId=" + employeeId + "]";
	}
}
