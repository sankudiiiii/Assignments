package person;
import bank.Account;
import bank.Loan;
public class Customer extends Person {
	private static int generateId = 200;
	private int customerId;
	private Loan loan;
	public Customer() {
		super();
	}
	public Customer(String name, Account account, Loan loan) {
		super(name, account);
		this.customerId = ++generateId;
		this.loan = loan;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Loan getLoan() {
		return loan;
	}
	public void setLoan(Loan loan) {
		this.loan = loan;
	}
	public String toString() {
		return super.toString()+" Customer [customerId=" + customerId + ", loan=" + loan + "]";
	}	
}