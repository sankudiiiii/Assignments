package bank;
public class Loan {
	private int amount;
	private int period;
	private double rate;
	public Loan() {}
	public Loan(int amount, int period, double rate) {
		super();
		this.amount = amount;
		this.period = period;
		this.rate = rate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public String toString() {
		return "Loan [amount=" + amount + ", period=" + period + ", rate="
				+ rate + "]";
	}
	public double calculateCompoundInterest(){
		return amount*Math.pow((rate+100)/100, period);
	}
}