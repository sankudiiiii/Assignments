package bank;
import person.Person;
public class Account {
	private static int generateId = 100;
	private int accountId;
	private double balance;
	public Account() {
		accountId = ++generateId;
		balance = 1000;
	}
	public Account(double balance) {
		super();
		accountId = ++generateId;
		this.balance = balance;
	}

	public static int getGenerateId() {
		return generateId;
	}
	public static void setGenerateId(int generateId) {
		Account.generateId = generateId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void add(Person person, int amount){
		this.balance+=amount;
	}
	public boolean subtract(Person person, int amount){
		if(this.balance-amount < 1000){
			return false;
		} else {
			this.balance-=amount;
			return true;			
		}
	}
	public String toString() {
		return "Account [accountId=" + accountId + ", balance=" + balance + "]";
	}
}