package bank;
public class SavingsAccount extends Account {
	public SavingsAccount() {
		super();
	}
	public SavingsAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}	
}