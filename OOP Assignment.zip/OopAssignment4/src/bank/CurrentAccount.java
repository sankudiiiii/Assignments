package bank;
public class CurrentAccount extends Account{
	public CurrentAccount() {
		super();
	}
	public CurrentAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
	}	
}