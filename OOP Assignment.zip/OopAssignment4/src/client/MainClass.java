package client;
import bank.CurrentAccount;
import bank.Loan;
import bank.SavingsAccount;
import person.Customer;
public class MainClass {
	public static void main(String[] args) {
		Customer c1 = new Customer("Sanket", new SavingsAccount(3000),null);
		Customer c2 = new Customer("Palash", new CurrentAccount(),new Loan(1000, 2, 5));
		c1.deposit(1000);
		c2.deposit(100);
		System.out.println(c1);
		System.out.println(c2);
		
		System.out.println(c2.getLoan().calculateCompoundInterest());
	}
}