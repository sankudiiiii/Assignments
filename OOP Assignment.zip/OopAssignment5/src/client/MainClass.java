package client;
import student.Student;
import dataManipulation.DataManipulation;
public class MainClass {
	public static void main(String[] args) {
		DataManipulation dm = new DataManipulation();
		Student s1 = new Student(1, "Sanket", 80.4);
		Student s2 = new Student(2, "Palash", 50.4);
		dm.insertData(s1);
		dm.insertData(s2);
		//dm.displayData();
		dm.deleteData(s1);
		dm.displayData();
	}
}