package dataManipulation;
import student.Student;
import dataInterface.DataInterface;
public class DataManipulation implements DataInterface{
	private static Student data[];
	public DataManipulation() {
		data = new Student[10];
	}
	public boolean insertData(Student student) {
		for (int i = 0; i < data.length; i++) {
			if (data[i] == null){
				data[i] = student;
				break;
			}
		}
		return true;
	}
	public boolean deleteData(Student student) {
		for (int i = 0; i < data.length; i++) {
			if (data[i] == student){
				data[i] = null;
				break;
			}
		}
		return true;
	}
	public boolean displayData() {
		for (int i = 0; i < data.length; i++) {
			if (data[i] != null){
				System.out.println(data[i]);
			}
		}
		return true;
	}
}