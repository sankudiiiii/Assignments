package dataInterface;
import student.Student;
public interface DataInterface {
	public boolean insertData(Student student);
	public boolean deleteData(Student student);
	public boolean displayData();	
}