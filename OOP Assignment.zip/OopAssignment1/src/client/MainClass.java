package client;
import assignment1.Student;
public class MainClass {
	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setName("Sanket");
		s1.setPercentage(50.36);
		s1.setRollNumber(1);
		System.out.println(s1);
		
		Student s2 = new Student(2, "Palash", 85.54);
		System.out.println(s2.getRollNumber());
		System.out.println(s2.getName());
		System.out.println(s2.getPercentage());
	}
}